__all__ = ["__version__", "version"]
__version__ = "0.1.2"
# Friendly alias
version = __version__
